module.exports = {
nomeProjeto: "Sistema de Gerenciamento de biblioteca"
versao: "1.0.0",
porta: 3000,
ambiente: "desenvolvimento",
};
